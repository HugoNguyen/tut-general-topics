﻿namespace Evently.Gateway.OpenTelemetry;

public static class DiagnosticsConfig
{
    public const string ServiceName = "Evently.Gateway";
}
