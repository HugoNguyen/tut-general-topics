﻿namespace Evently.Ticketing.Api.OpenTelemetry;

public static class DiagnosticsConfig
{
    public const string ServiceName = "Evently.Ticketing.Api";
}
