﻿namespace Evently.Modules.Users.Presentation;

internal static class Permissions
{
    internal const string GetUser = "users:read";
    internal const string ModifyUser = "users:update";
}
