﻿namespace Evently.Modules.Attendance.Presentation;

internal static class Tags
{
    internal const string Attendees = "Attendees";
    internal const string EventStatistics = "EventStatistics";
}
