﻿namespace Evently.Modules.Attendance.Infrastructure.Database;

internal static class Schemas
{
    internal const string Attendance = "attendance";
}
