﻿namespace Evently.Modules.Events.Api.Database;

internal static class Schemas
{
    internal const string Events = "events";
}
