﻿namespace Evently.Modules.Events.Api;

internal static class Tags
{
    internal const string Events = "Events";
}
