﻿namespace Evently.Modules.Events.Presentation;

internal static class Tags
{
    internal const string Events = "Events";
}
