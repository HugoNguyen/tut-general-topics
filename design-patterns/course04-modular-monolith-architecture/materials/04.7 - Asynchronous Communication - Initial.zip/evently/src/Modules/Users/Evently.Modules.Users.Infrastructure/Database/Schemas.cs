﻿namespace Evently.Modules.Users.Infrastructure.Database;

internal static class Schemas
{
    internal const string Users = "users";
}
