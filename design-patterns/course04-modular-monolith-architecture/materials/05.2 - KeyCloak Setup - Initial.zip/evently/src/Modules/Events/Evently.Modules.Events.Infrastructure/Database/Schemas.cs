﻿namespace Evently.Modules.Events.Infrastructure.Database;

internal static class Schemas
{
    internal const string Events = "events";
}
