﻿namespace Evently.Modules.Users.Presentation;

internal static class Tags
{
    internal const string Users = "Users";
}
