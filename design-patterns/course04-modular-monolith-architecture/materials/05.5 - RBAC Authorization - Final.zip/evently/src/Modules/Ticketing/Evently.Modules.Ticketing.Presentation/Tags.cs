﻿namespace Evently.Modules.Ticketing.Presentation;

internal static class Tags
{
    internal const string Carts = "Carts";
    internal const string Orders = "Orders";
    internal const string Tickets = "Tickets";
}
